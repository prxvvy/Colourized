/* Colourized - A program to add colour to Node.js console output.
 * Copyright (C) 2022 prxvvy <qsk55464@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import bindings from 'bindings';

const addon = bindings('colorized_lib');

type dict = { [key: string]: any };

const colours: dict = {
	// Foreground
	black: addon.black,
	red: addon.red,
	yellow: addon.yellow,
	green: addon.green,
	blue: addon.blue,
	magenta: addon.magenta,
	grey: addon.grey,
	gray: addon.grey,
	white: addon.white,
	cyan: addon.cyan,
	lightRed: addon.lightRed,
	lightYellow: addon.lightYellow,
	lightGreen: addon.lightGreen,
	lightBlue: addon.lightBlue,
	lightGrey: addon.lightGrey,
	lightGray: addon.lightGrey,
	lightCyan: addon.lightCyan,
	lightMagenta: addon.lightMagenta,
	lightWhite: addon.lightWhite,
	// Background
	bgRed: addon.bgRed,
	bgBlack: addon.bgBlack,
	bgGreen: addon.bgGreen,
	bgYellow: addon.bgYellow,
	bgBlue: addon.bgBlue,
	bgMagenta: addon.bgMagenta,
	bgCyan: addon.bgCyan,
	bgWhite: addon.bgWhite,
	bgGrey: addon.bgGrey,
	bgGray: addon.bgGrey,
	bgLightRed: addon.bgLightRed,
	bgLightGreen: addon.bgLightGreen,
	bgLightYellow: addon.bgLightYellow,
	bgLightBlue: addon.bgLightBlue,
	bgLightMagenta: addon.bgLightMagenta,
	bgLightCyan: addon.bgLightCyan,
	bgLightWhite: addon.bgLightWhite,
	bgLightGrey: addon.bgLightGrey,
	bgLightGray: addon.bgLightGrey,
};

const styles: dict = {
	underline: addon.underline,
	bold: addon.bold,
	dim: addon.dim,
	italic: addon.italic,
	inverse: addon.inverse,
};

class Colourized {
	public str: string[];
	constructor() {
		this.str = [];
		const ref = Object.assign({}, colours, styles);
		const all = Object.keys(ref);

		all.forEach((func) => {
			const obj = {
				[func]: {
					str: this.str,
					get() {
						this.str.push(ref[func]);
						const colourIt = (txt: string) => {
							if (!txt) throw new Error('1 argument expected.');
							for (const funcName of this.str.reverse()) {
								txt = (funcName as unknown as Function)(txt);
							}
							this.str = [];
							return txt;
						};

						colourIt.__proto__ = this;
						return colourIt;
					},
				},
			};
			Object.defineProperties(Colourized.prototype, obj);
		});
	}
}

export = new Colourized();
